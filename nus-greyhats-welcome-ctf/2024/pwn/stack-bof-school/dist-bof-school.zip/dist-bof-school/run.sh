stty -icanon -echo ; ./challenge; stty sane
